/*package com.fur.dao;
import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fur.model.UserDetails;

@Repository("userdetailsDAO")
public class UserDetailsDAOImpl {

	@Autowired
	private SessionFactory sessionFactory;
	
	public UserDetailsDAOImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	public boolean save(UserDetails UserDetails)
	{
	try {
		sessionFactory.getCurrentSession().save(UserDetails);	
		return true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return false;
	}
	}
	public boolean update(UserDetails UserDetails)
	{
		try {
			sessionFactory.getCurrentSession().update(UserDetails);	
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public boolean delete(UserDetails UserDetails)
	{
		try {
			sessionFactory.getCurrentSession().delete(UserDetails);	
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	public UserDetails get(String id)
	{
		String hql=" from UserDetails where id ="+"'"+id+"'";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		List<UserDetails> list=query.list();
		if(list==null)
		{
			return null;
		}
		else
		{
			return list.get(0);
		}
	}
	public List<UserDetails> list()
	{
		String hql=" from UserDetails";
		Query query=sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

}
*/