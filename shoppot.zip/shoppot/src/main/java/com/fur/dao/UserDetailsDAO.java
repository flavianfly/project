package com.fur.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.fur.model.UserDetails;


public interface UserDetailsDAO {

	public boolean save(UserDetails UserDetails);
	public boolean update(UserDetails UserDetails);
	public boolean delete(UserDetails UserDetails);
	public UserDetails get(String id);
	public List<UserDetails> list();

}
