package com.fur.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fur.model.Product;
import com.fur.service.ProductService;
import com.google.gson.Gson;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;

	public ProductController() {
		// super();
		// TODO Auto-generated constructor stub
		System.out.println("product controller");
	}

	@RequestMapping("adminproduct")
	public ModelAndView getadmin(@ModelAttribute("prod") Product prod) {
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
	}

	@RequestMapping("/listProduct")
	public@ResponseBody ModelAndView gotoAdd(ModelMap m)
	{
		List<Product> productList=productService.getList();
		Gson gson=new Gson();
		String st=gson.toJson(productList);
		m.addAttribute("pdata",st);
		 return new ModelAndView("listProduct");
	}
	
	/*public ModelAndView gotoProduct(@ModelAttribute("prod") Product prod) {
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
		
	}
*/
	@RequestMapping(value = "saveProduct", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("prod") Product prod) {
		productService.insertRow(prod);
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
	}

	// @RequestMapping("register")
	// public ModelAndView registerUser(@ModelAttribute Product product) {
	// productService.insertRow(product);
	// return new ModelAndView("redirect:list");
	// }

	@RequestMapping("list")
	public ModelAndView getList() {
		List productList = productService.getList();
		return new ModelAndView("list", "ProductList", productList);
	}

	@RequestMapping("deleteProduct")
	public ModelAndView deleteUser(@ModelAttribute("prod")Product prod,@RequestParam int id) {
		productService.deleteRow(id);
		List productList = productService.getList();
		return new ModelAndView("adminproduct","ProductList", productList);
	}

	@RequestMapping("editproduct")
	public ModelAndView editUser(@ModelAttribute("prod") Product prod, @RequestParam int id) 
	{
		prod = productService.getRowById(id);
		List productList = productService.getList();
		return new ModelAndView("editproduct", "ProductObject", prod);
	}

	@RequestMapping("updateProduct")
	public ModelAndView updateUser(@ModelAttribute("prod") Product prod) {
		productService.updateRow(prod);
		List productList = productService.getList();
		return new ModelAndView("redirect:adminproduct");
	}

}
