package com.fur.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.fur.model.Category;
import com.fur.service.CategoryService;
import com.google.gson.Gson;

@Controller
public class CategoryController {

	@Autowired
	CategoryService categoryService;

	public CategoryController() {
		// super();
		// TODO Auto-generated constructor stub
		System.out.println("category controller");
	}

	@RequestMapping("/admincategory")
	public ModelAndView getadmin(@ModelAttribute("cate") Category cate) {
		List categoryList = categoryService.getList();
		return new ModelAndView("admincategory", "categoryList", categoryList);
	}

	@RequestMapping("/listCategory")
	public@ResponseBody ModelAndView gotoAdd(ModelMap m)
	{
		List<Category> categoryList=categoryService.getList();
		Gson gson=new Gson();
		String st=gson.toJson(categoryList);
		m.addAttribute("cdata",st);
		 return new ModelAndView("listCategory");
	}
	
	/*public ModelAndView gotoProduct(@ModelAttribute("prod") Product prod) {
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
		
	}
*/
	@RequestMapping(value = "saveCategory", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("cate") Category cate) {
		
		categoryService.insertRow(cate);
		List categoryList = categoryService.getList();
		return new ModelAndView("admincategory", "categoryList", categoryList);
	}

	// @RequestMapping("register")
	// public ModelAndView registerUser(@ModelAttribute Product product) {
	// productService.insertRow(product);
	// return new ModelAndView("redirect:list");
	// }

	@RequestMapping("list3")
	public ModelAndView getList() {
		List categoryList = categoryService.getList();
		return new ModelAndView("list", "categoryList", categoryList);
	}

	@RequestMapping("/deleteCategory")
	public ModelAndView deleteUser(@ModelAttribute("cate")Category cate,@RequestParam int id) {
		categoryService.deleteRow(id);
		List categoryList = categoryService.getList();
		return new ModelAndView("admincategory","categoryList", categoryList);
	}

	@RequestMapping("/editcategory")
	public ModelAndView editUser(@ModelAttribute("cate") Category cate, @RequestParam int id) 
	{
		cate = categoryService.getRowById(id);
		List categoryList = categoryService.getList();
		return new ModelAndView("editcategory", "CategoryObject", cate);
	}

	@RequestMapping("/updateCategory")
	public ModelAndView updateUser(@ModelAttribute("cate") Category cate) {
		categoryService.updateRow(cate);
		List categoryList = categoryService.getList();
		return new ModelAndView("redirect:admincategory");
	}

}
