package com.fur.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.fur.model.Category;
import com.fur.model.Product;
import com.fur.model.Supplier;
import com.fur.service.CategoryService;
import com.fur.service.ProductService;
import com.fur.service.SupplierService;
import com.google.gson.Gson;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;
	
	@Autowired
	CategoryService categoryService;

	@Autowired
	SupplierService supplierService;


	public ProductController() {
		// super();
		// TODO Auto-generated constructor stub
		System.out.println("product controller");
	}

	@RequestMapping("/adminproduct")
	public ModelAndView getadmin(@ModelAttribute("product") Product product , Model a) {
		List<Supplier> x =supplierService.getList();
		a.addAttribute("sList",x);
		List<Category> ab =categoryService.getList();
		a.addAttribute("cList",ab);
		
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "productList", productList);
	}

	@RequestMapping("/listProduct")
	public@ResponseBody ModelAndView gotoAdd(ModelMap m)
	{
		List<Product> productList=productService.getList();
		Gson gson=new Gson();
		String st=gson.toJson(productList);
		m.addAttribute("pdata",st);
		 return new ModelAndView("listProduct");
	}
	
	/*public ModelAndView gotoProduct(@ModelAttribute("prod") Product prod) {
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
		
	}
*/
	@RequestMapping(value = "saveProduct", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("product") Product product,ModelMap m) {
		
		  MultipartFile file = product.getFile(); 
		  String fileName = "";
		  
		  String image="";
		  if(!file.isEmpty())		 
		  {
			  try 
			  {
				  System.out.println("inside try");
			  fileName = file.getOriginalFilename();
			  byte[] filesize=file.getBytes();
			  BufferedOutputStream bout=new BufferedOutputStream(new FileOutputStream(new File("C:\\Users\\hi\\workspace\\shoppot\\src\\main\\webapp\\resources\\imgs\\" + fileName)));
			   bout.write(filesize);
			   bout.close();
			   image="/resources/imgs/"+fileName;
			  // r.setAttribute("imgs",image);
			   m.addAttribute("imgs", image);
			   System.out.println("upload success.."+image);
			  }
			   catch (IOException e) {
			   // TODO Auto-generated catch block
				  System.out.println("upload failed..");
			   e.printStackTrace();
			  }
			 
		  }
		productService.insertRow(product, image);
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "productList", productList);
	}

	// @RequestMapping("register")
	// public ModelAndView registerUser(@ModelAttribute Product product) {
	// productService.insertRow(product);
	// return new ModelAndView("redirect:list");
	// }

	@RequestMapping("list")
	public ModelAndView getList() {
		List productList = productService.getList();
		return new ModelAndView("list", "productList", productList);
	}

	@RequestMapping("deleteProduct")
	public ModelAndView deleteUser(@ModelAttribute("product")Product product,@RequestParam int id) {
		productService.deleteRow(id);
		List productList = productService.getList();
		return new ModelAndView("adminproduct","productList", productList);
	}

	@RequestMapping("editproduct")
	public ModelAndView editUser(@ModelAttribute("product") Product product, @RequestParam int id) 
	{
		product = productService.getRowById(id);
		List productList = productService.getList();
		return new ModelAndView("editproduct", "ProductObject", product);
	}

	@RequestMapping("updateProduct")
	public ModelAndView updateUser(@ModelAttribute("product") Product product) {
		productService.updateRow(product);
		List productList = productService.getList();
		return new ModelAndView("redirect:adminproduct");
	}

}
