package com.fur.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fur.model.Product;
import com.fur.service.ProductService;

@Controller
public class Shop {
	public Shop() {

		System.out.println("inside controller");
	}


	@Autowired
	ProductService productService;
	@RequestMapping("/")
	public String gotoindexPage() {
		return "index";
	}

	@RequestMapping("/invalid")
	public String gotoinvalidPage() {
		return "invalid";
	}

	@RequestMapping("/home")
	public String gotoHome() {
		return "home";
	}

	@RequestMapping("/register")
	public String gotoregister() {
		return "register";
	}

	@RequestMapping("/welcome")
	public String gotowelcome() {
		return "welcome";
	}
	
	@RequestMapping("/pay")
	public String gotoweme() {
		return "pay";
	}
	
	@RequestMapping("/welcome2")
	public String gotowelcome2() {
		return "welcome2";
	}
	
	
	@RequestMapping("/hall")
	public ModelAndView getadmin(@ModelAttribute("product") Product product , Model a) {
	List productList = productService.getList();
	return new ModelAndView("hall", "productList", productList);

	}
	
	@RequestMapping("/bedroom")
	public ModelAndView getadmi(@ModelAttribute("product") Product product , Model a) {
		List productList = productService.getList();
		return new ModelAndView("bedroom", "productList", productList);

	}
	
	@RequestMapping("/dinning")
	public ModelAndView getadminn(@ModelAttribute("product") Product product , Model a) {
		List productList = productService.getList();
		return new ModelAndView("dinning", "productList", productList);

	}
	

	@RequestMapping("/aboutus")
	public String gotobem() {
		return "aboutus";
	}
	
	
	
	
	@RequestMapping("/adminlogin")
	public String gotobeq() {
		return "adminlogin";
	}
	

	
	@RequestMapping("/ha1")
	public String gotoha1() {
		return "ha1";
	}

	@RequestMapping("/ha2")
	public String gotoha2() {
		return "ha2";
	}
	
	@RequestMapping("/ha3")
	public String gotoha3() {
		return "ha3";
	}
	
	@RequestMapping("/ha4")
	public String gotoha4() {
		return "ha4";
	}
	
	@RequestMapping("/ha5")
	public String gotoha5() {
		return "ha5";
	}
	
	@RequestMapping("/ha6")
	public String gotoha6() {
		return "ha6";
	}


	@RequestMapping("/index1")
	public String gotoindex1() {
		return "index1";
	}

	

	@RequestMapping(value = "/checkLogin",method = RequestMethod.POST)
	public String validateLogin(HttpServletRequest req) {
		String u = req.getParameter("username");
		String pass = req.getParameter("pwd");
		if ((u.equals("abc")) && (pass.equals("def")))
		{
			return "welcome";
		} 
		else 
		{

			return "invalid";
		}

	}
	
	
	@RequestMapping("/index")
	public String gotologin(@RequestParam(value="error",required = false) String error, @RequestParam(value="logout",required = false) String logout, Model model) 
	{
		
		if(error!=null)
		{
			model.addAttribute("error","Invalid  to enter");
		}
		if(logout!=null)
		{
			model.addAttribute("msg", "logged out successfully");
		}
		return  "index";
  	}

}
