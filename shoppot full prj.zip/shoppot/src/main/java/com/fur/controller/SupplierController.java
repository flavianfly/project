package com.fur.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.fur.model.Supplier;
import com.fur.service.SupplierService;
import com.google.gson.Gson;

@Controller
public class SupplierController {

	@Autowired
	SupplierService supplierService;

	public SupplierController() {
		// super();
		// TODO Auto-generated constructor stub
		System.out.println("supplier controller");
	}

	@RequestMapping("/adminsupplier")
	public ModelAndView getadmin(@ModelAttribute("supp") Supplier supp) {
		List supplierList = supplierService.getList();
		return new ModelAndView("adminsupplier", "supplierList", supplierList);
	}

	@RequestMapping("/listSupplier")
	public@ResponseBody ModelAndView gotoAdd(ModelMap m)
	{
		List<Supplier> supplierList=supplierService.getList();
		Gson gson=new Gson();
		String st=gson.toJson(supplierList);
		m.addAttribute("sdata",st);
		 return new ModelAndView("listSupplier");
	}
	
	/*public ModelAndView gotoProduct(@ModelAttribute("prod") Product prod) {
		List productList = productService.getList();
		return new ModelAndView("adminproduct", "ProductList", productList);
		
	}
*/
	@RequestMapping(value = "saveSupplier", method = RequestMethod.POST)
	public ModelAndView getForm(@ModelAttribute("supp") Supplier supp) {
		
		supplierService.insertRow(supp);
		List supplierList = supplierService.getList();
		return new ModelAndView("adminsupplier", "supplierList", supplierList);
	}

	// @RequestMapping("register")
	// public ModelAndView registerUser(@ModelAttribute Product product) {
	// productService.insertRow(product);
	// return new ModelAndView("redirect:list");
	// }

	@RequestMapping("list1")
	public ModelAndView getList() {
		List supplierList = supplierService.getList();
		return new ModelAndView("list", "supplierList", supplierList);
	}

	@RequestMapping("/deleteSupplier")
	public ModelAndView deleteUser(@ModelAttribute("supp")Supplier supp,@RequestParam int id) {
		supplierService.deleteRow(id);
		List supplierList = supplierService.getList();
		return new ModelAndView("adminsupplier","supplierList", supplierList);
	}

	@RequestMapping("/editsupplier")
	public ModelAndView editUser(@ModelAttribute("supp") Supplier supp, @RequestParam int id) 
	{
		supp = supplierService.getRowById(id);
		List supplierList = supplierService.getList();
		return new ModelAndView("editsupplier", "SupplierObject", supp);
	}

	@RequestMapping("/updateSupplier")
	public ModelAndView updateUser(@ModelAttribute("supp") Supplier supp) {
	supplierService.updateRow(supp);
		List supplierList = supplierService.getList();
		return new ModelAndView("redirect:adminsupplier");
	}

}
