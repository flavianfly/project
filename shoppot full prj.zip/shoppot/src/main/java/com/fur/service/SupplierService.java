package com.fur.service;

import java.util.List;

import com.fur.model.Supplier;

public interface SupplierService {
 
 public int insertRow(Supplier supp);

 public List getList();

 public Supplier getRowById(int id);

 public int updateRow(Supplier supp);

 public int deleteRow(int id);

}

